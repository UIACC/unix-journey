"""Demo file"""


def greet(name):
    """Print a greeting"""
    print(f'Hello {name}!')


if __name__ == '__main__':
    greet('Vim')
